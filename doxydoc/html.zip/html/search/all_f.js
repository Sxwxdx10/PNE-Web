var searchData=
[
  ['the_20mit_20license_20mit_0',['The MIT License (MIT)',['../md__c_1_2_users_2maxim_2_desktop_2_prog_01uni_2_uni_012_2_projet_01nautique_2pne-admin_2src_2_p_cda36e18d516ff5193f5ea44e11b29cf.html',1,'']]]
];
